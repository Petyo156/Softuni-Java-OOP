package _5_Тelephony;

public interface Callable {
    String call();
}
