package _5_Тelephony;

public interface Browsable {
    String browse();
}
