package climbers.models.climber;

public class WallClimber extends BaseClimber{
    public WallClimber(String name) {
        super(name, 90);
    }
}
