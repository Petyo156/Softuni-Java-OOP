package harpoonDiver.models.diver;

public class WreckDiver extends BaseDiver implements Diver{
    public WreckDiver(String name) {
        super(name, 150);
    }
}
